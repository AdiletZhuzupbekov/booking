package kg.megacom.booking.microservices.json.enums;

public enum ApartmentClassification {
    SINGLE,
    LUXURY,
    EXTRA_LUXURY,
    PRESIDENT;
}
