package kg.megacom.booking_service.service.impl;

import kg.megacom.booking_service.service.CustomerService;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {


}
