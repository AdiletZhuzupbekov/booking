package kg.megacom.booking_service.model.enums;

public enum ApartmentClassification {
    SINGLE,
    LUXURY,
    EXTRA_LUXURY,
    PRESIDENT;
}
