package kg.megacom.booking_service.service;

public interface CustomerService {
}
