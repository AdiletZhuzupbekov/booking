package kg.megacom.booking_service.model.enums;

public enum BookStatus {
    BOOKED,
    AVAILABLE;

}
